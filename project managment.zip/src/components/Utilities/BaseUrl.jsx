// const BASE_URL= "https://hrb5wx2v-8800.inc1.devtunnels.ms/api/";
const BASE_URL= "https://eminoids-backend-production.up.railway.app/api/";


export default BASE_URL